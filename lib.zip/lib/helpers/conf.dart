import 'package:flutter/material.dart';

class Palette {
  static Color white1 = const Color.fromRGBO(247, 248, 250, 1);
  static Color blue1 = const Color.fromRGBO(1, 43, 85, 1);
}