class Datum {
  String title;
  String description;

  Datum({
    required this.title,
    required this.description
  });
}